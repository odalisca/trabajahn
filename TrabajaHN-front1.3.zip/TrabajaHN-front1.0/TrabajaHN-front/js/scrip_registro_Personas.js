document.addEventListener('DOMContentLoaded', function () {
    // Evento para cambiar las opciones de ciudad según el departamento seleccionado
    document.getElementById('departamento').addEventListener('change', function () {
        const ciudades = {
            'Francisco Morazan': ['Tegucigalpa', 'Ojojona', 'Tamara'],
            'Cortes': ['San Pedro Sula', 'Lima', 'Otra'],
            // Añade más ciudades según el departamento
        };

        const departamentoSeleccionado = this.value;
        const ciudadSelect = document.getElementById('ciudad');

        ciudadSelect.innerHTML = '<option value="" disabled selected>Seleccione la ciudad</option>';

        ciudades[departamentoSeleccionado]?.forEach(function (ciudad) {
            const opcion = document.createElement('option');
            opcion.value = ciudad;
            opcion.textContent = ciudad;
            ciudadSelect.appendChild(opcion);
        });
    });

    // Validación de campos de texto (no permiten números)
    document.querySelectorAll('input[type="text"]').forEach(function (input) {
        input.addEventListener('input', function () {
            this.value = this.value.replace(/\d/g, '');
        });
    });

    // Validación de campos numéricos (solo permiten números)
    document.querySelectorAll('input[type="number"]').forEach(function (input) {
        input.addEventListener('input', function () {
            this.value = this.value.replace(/[^\d]/g, '');
        });
    });

    // Validaciones y manejo de envío de formulario
    document.getElementById('registerForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData.entries());
        let isValid = true;

        // Validaciones
        if (!validateText(data.nombre)) {
            markInvalid('nombre');
            isValid = false;
        } else {
            markValid('nombre');
        }

        if (!validateText(data.apellido)) {
            markInvalid('apellido');
            isValid = false;
        } else {
            markValid('apellido');
        }

        if (!validateDate(data.fecha_nacimiento)) {
            markInvalid('fecha_nacimiento');
            isValid = false;
        } else {
            markValid('fecha_nacimiento');
        }

        const departamento = document.getElementById('departamento').value;
        const ciudad = document.getElementById('ciudad').value;
        const direccionEspecifica = document.getElementById('direccion_especifica').value;

        const direccionCompleta = `${departamento}, ${ciudad}, ${direccionEspecifica}`;
        document.getElementById('direccion').value = direccionCompleta;

        if (direccionCompleta.trim() === '' || departamento === '' || ciudad === '' || direccionEspecifica.trim() === '') {
            alert('Por favor, complete todos los campos de dirección correctamente.');
            isValid = false;
        }

        if (isValid) {
            alert('Registro exitoso');
            // Aquí puedes agregar la lógica para enviar los datos al servidor
            // event.target.submit(); // Descomenta esta línea para enviar el formulario si todo es válido
        }
    });
});

function validateText(text) {
    return text && /^[a-zA-Z\s]+$/.test(text);
}

function validateDate(date) {
    return !isNaN(Date.parse(date));
}

function validatePhone(phone) {
    return phone && /^\d{8}$/.test(phone);
}

function validateEmail(email) {
    return email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateNumber(number) {
    return !isNaN(number) && number > 0;
}

function markInvalid(fieldId) {
    document.getElementById(fieldId).classList.add('invalid');
}

function markValid(fieldId) {
    document.getElementById(fieldId).classList.remove('invalid');
}
