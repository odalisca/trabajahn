document.getElementById('empresaRegisterForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    let isValid = true;

    // Validaciones
    if (!validateText(data.nombre)) {
        markInvalid('nombre');
        isValid = false;
    } else {
        markValid('nombre');
    }
    if (!validateCIF(data.cif)) {
        markInvalid('cif');
        isValid = false;
    } else {
        markValid('cif');
    }
    if (data.director && !validateText(data.director)) {
        markInvalid('director');
        isValid = false;
    } else {
        markValid('director');
    }
    if (data.direccion && !validateAddress(data.direccion)) {
        markInvalid('direccion');
        isValid = false;
    } else {
        markValid('direccion');
    }
    if (data.telefono && !validatePhone(data.telefono)) {
        markInvalid('telefono');
        isValid = false;
    } else {
        markValid('telefono');
    }
    if (data.email && !validateEmail(data.email)) {
        markInvalid('email');
        isValid = false;
    } else {
        markValid('email');
    }

    if (isValid) {
        // Aquí puedes agregar la lógica para enviar los datos al servidor
        alert('Registro exitoso');
    }
});

function validateText(text) {
    return text && /^[a-zA-Z\s]+$/.test(text);
}

function validateCIF(cif) {
    return cif && /^[a-zA-Z0-9]+$/.test(cif);
}

function validateAddress(address) {
    return address && address.trim().length > 0;
}

function validatePhone(phone) {
    return phone && /^\d{8,20}$/.test(phone);
}

function validateEmail(email) {
    return email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function markInvalid(fieldId) {
    document.getElementById(fieldId).classList.add('invalid');
}

function markValid(fieldId) {
    document.getElementById(fieldId).classList.remove('invalid');
}
