CREATE DATABASE Agencia_Empleo;
GO

USE Agencia_Empleo;
GO

-- Creacion de tablas
CREATE TABLE Personas (
    ID_Persona INTEGER NOT NULL,
    Nombre VARCHAR (100) NOT NULL,
    Apellido VARCHAR (100) NOT NULL,
    Fecha_Nacimiento DATE NOT NULL,
    Direccion VARCHAR NOT NULL,
    Telefono VARCHAR (20),
    Email VARCHAR (100),
    CONSTRAINT Personas_PK PRIMARY KEY CLUSTERED (ID_Persona)
);
GO

CREATE TABLE Solicitantes (
    ID_Persona INTEGER NOT NULL,
    Estado BINARY,
    CONSTRAINT Solicitantes_PK PRIMARY KEY (ID_Persona),
    CONSTRAINT Solicitantes_Personas_FK FOREIGN KEY (ID_Persona)
        REFERENCES Personas (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Empresas (
    ID_Empresa INTEGER NOT NULL IDENTITY,
    Nombre VARCHAR (100) NOT NULL,
    CIF VARCHAR (50) NOT NULL,
    Director VARCHAR (100),
    Direccion VARCHAR (255),
    Telefono VARCHAR (20),
    Email VARCHAR (100),
    Estado BINARY,
    CONSTRAINT Empresas__IDX PRIMARY KEY CLUSTERED (ID_Empresa)
);
GO

CREATE TABLE Puestos_Trabajo (
    ID_Puesto INTEGER NOT NULL IDENTITY,
    Tipo_Puesto VARCHAR (100) NOT NULL,
    Sueldo DECIMAL (10,2),
    Condiciones VARCHAR (200),
    ID_Empresa INTEGER NOT NULL,
    CONSTRAINT Puestos_Trabajo__IDX PRIMARY KEY CLUSTERED (ID_Puesto),
    CONSTRAINT Facturas_FK0v7 FOREIGN KEY (ID_Empresa)
        REFERENCES Empresas (ID_Empresa)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Tipo_Contratos (
    IdTipoContrato INTEGER NOT NULL,
    TipoContrato VARCHAR (100) NOT NULL,
    SueldoBase FLOAT,
    SalarioPorHora FLOAT,
    horasContrato INTEGER,
    CONSTRAINT Tipo_Contratos_PK PRIMARY KEY CLUSTERED (IdTipoContrato)
);
GO

CREATE TABLE Contratos (
    Sueldo FLOAT NOT NULL,
    ID_Puesto INTEGER NOT NULL,
    IdTipoContrato INTEGER NOT NULL,
    CONSTRAINT Contratos_Puestos_Trabajo_FK FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Contratos_Tipo_Contratos_FK FOREIGN KEY (IdTipoContrato)
        REFERENCES Tipo_Contratos (IdTipoContrato)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Datos_Legales (
    ID_Legal INTEGER NOT NULL IDENTITY,
    ID_Solicitante INTEGER NOT NULL,
    Servicio_Militar VARCHAR (50),
    Relacion_Justicia VARCHAR (200),
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Datos_Legales__IDX PRIMARY KEY CLUSTERED (ID_Legal),
    CONSTRAINT Facturas_FK0v2 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Datos_Sanitarios (
    ID_Sanitario INTEGER NOT NULL IDENTITY,
    ID_Persona INTEGER NOT NULL,
    Informacion_Sanitaria VARCHAR (200),
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Datos_Sanitarios__IDX PRIMARY KEY CLUSTERED (ID_Sanitario),
    CONSTRAINT Facturas_FK0v1 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Estudios (
    ID_Estudio INTEGER NOT NULL IDENTITY,
    ID_Solicitante INTEGER NOT NULL,
    Tipo_Estudio VARCHAR (100),
    Especialidad VARCHAR (100),
    Calificacion_Media DECIMAL (3,2),
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Estudios__IDX PRIMARY KEY CLUSTERED (ID_Estudio),
    CONSTRAINT Facturas_FK0v3 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Experiencia_Laboral (
    ID_Experiencia INTEGER NOT NULL IDENTITY,
    ID_Solicitante INTEGER NOT NULL,
    Empresa VARCHAR (100),
    Puesto VARCHAR (100),
    Anios_Experiencia INTEGER,
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Experiencia_Laboral__IDX PRIMARY KEY CLUSTERED (ID_Experiencia),
    CONSTRAINT Facturas_FK0v4 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE TipoRelacion (
    IDRelacion INTEGER NOT NULL,
    Relacion VARCHAR (100) NOT NULL,
    CONSTRAINT TipoRelacion_PK PRIMARY KEY CLUSTERED (IDRelacion)
);
GO

CREATE TABLE Familiares (
    ID_Familiar INTEGER NOT NULL IDENTITY,
    Solicitantes_ID_Persona INTEGER NOT NULL,
    ID_Persona_Familiar INTEGER,
    IDRelacion INTEGER NOT NULL,
    Nombre VARCHAR (100) NOT NULL,
    Telefono VARCHAR (20),
    CONSTRAINT Familiares__IDX PRIMARY KEY CLUSTERED (ID_Familiar),
    CONSTRAINT Familiares_Personas_FK FOREIGN KEY (ID_Persona_Familiar)
        REFERENCES Personas (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Familiares_TipoRelacion_FK FOREIGN KEY (IDRelacion)
        REFERENCES TipoRelacion (IDRelacion)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Pagos_Empresas (
    ID_Pago INTEGER NOT NULL IDENTITY,
    ID_Empresa INTEGER NOT NULL,
    Monto_Puesto DECIMAL (10,2),
    Numero_Trabajadores INTEGER,
    Fecha_Pago DATE,
    CONSTRAINT Pagos_Empresas__IDX PRIMARY KEY CLUSTERED (ID_Pago),
    CONSTRAINT Facturas_FK0v12 FOREIGN KEY (ID_Empresa)
        REFERENCES Empresas (ID_Empresa)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Pagos_Solicitantes (
    ID_Pago INTEGER NOT NULL IDENTITY,
    ID_Solicitante INTEGER NOT NULL,
    Monto_Inicial DECIMAL (10,2),
    Porcentaje_Sueldo DECIMAL (5,2),
    Fecha_Pago DATE,
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Pagos_Personas__IDX PRIMARY KEY CLUSTERED (ID_Pago),
    CONSTRAINT Facturas_FK0v11 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Tipos_Factura (
    ID_Tipo_Factura INTEGER NOT NULL IDENTITY,
    Descripcion VARCHAR (50) NOT NULL,
    ID_Pago_Solicitante INTEGER,
    ID_Pago_Empresa INTEGER,
    CONSTRAINT Tipos_Factura__IDX PRIMARY KEY CLUSTERED (ID_Tipo_Factura),
    CONSTRAINT Facturas_FK0v13 FOREIGN KEY (ID_Pago_Solicitante)
        REFERENCES Pagos_Solicitantes (ID_Pago)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Facturas_FK0v14 FOREIGN KEY (ID_Pago_Empresa)
        REFERENCES Pagos_Empresas (ID_Pago)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Facturas (
    ID_Factura INTEGER NOT NULL IDENTITY,
    Fecha_Factura DATE NOT NULL,
    Monto_Total DECIMAL (10,2) NOT NULL,
    ID_Tipo_Factura INTEGER NOT NULL,
    CONSTRAINT Facturas__IDX PRIMARY KEY CLUSTERED (ID_Factura),
    CONSTRAINT Facturas_FK0v15 FOREIGN KEY (ID_Tipo_Factura)
        REFERENCES Tipos_Factura (ID_Tipo_Factura)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Puestos_Personas (
    ID_Puesto INTEGER NOT NULL,
    ID_Solicitante INTEGER NOT NULL,
    CONSTRAINT Puestos_Personas_PK PRIMARY KEY CLUSTERED (ID_Puesto, ID_Solicitante),
    CONSTRAINT Facturas_FK0v8 FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Facturas_FK0v9 FOREIGN KEY (ID_Solicitante)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Requisitos (
    IdRequisito INTEGER NOT NULL,
    Requisito VARCHAR (100) NOT NULL,
    CONSTRAINT Requisitos_PK PRIMARY KEY CLUSTERED (IdRequisito)
);
GO

CREATE TABLE TiposRequisitos (
    IDTipoRequisito INTEGER NOT NULL,
    IdRequisito INTEGER NOT NULL,
    ID_Puesto INTEGER NOT NULL,
    Tipo VARCHAR (100) NOT NULL,
    CONSTRAINT TiposRequisitos_PK PRIMARY KEY CLUSTERED (IDTipoRequisito),
    CONSTRAINT TiposRequisitos_Requisitos_FK FOREIGN KEY (IdRequisito)
        REFERENCES Requisitos (IdRequisito)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT TiposRequisitos_Puestos_Trabajo_FK FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Historial (
    ID_Historial INTEGER NOT NULL,
    Fecha DATE NOT NULL,
    Usuario VARCHAR (100),
    Metodo VARCHAR (100),
    Tabla_Afectada VARCHAR,
    CONSTRAINT Historial_PK PRIMARY KEY CLUSTERED (ID_Historial)
);
GO

CREATE TABLE Tipos_Historial (
    Tipos_Factura_ID_Tipo_Factura INTEGER,
    Personas_ID_Persona INTEGER,
    Puestos_Trabajo_ID_Puesto INTEGER,
    Historial_ID_Historial INTEGER NOT NULL,
    CONSTRAINT Tipos_Historial_PK PRIMARY KEY CLUSTERED (Historial_ID_Historial),
    CONSTRAINT Tipos_Historial_Historial_FK FOREIGN KEY (Historial_ID_Historial)
        REFERENCES Historial (ID_Historial)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Tipos_Historial_Personas_FK FOREIGN KEY (Personas_ID_Persona)
        REFERENCES Personas (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Tipos_Historial_Puestos_Trabajo_FK FOREIGN KEY (Puestos_Trabajo_ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Tipos_Historial_Tipos_Factura_FK FOREIGN KEY (Tipos_Factura_ID_Tipo_Factura)
        REFERENCES Tipos_Factura (ID_Tipo_Factura)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Solicitudes_Empleo (
    ID_Solicitud INTEGER NOT NULL IDENTITY,
    Tipo_Puesto_Solicitado VARCHAR (100),
    Limitaciones VARCHAR (200),
    Deseos VARCHAR (200),
    SalarioMax FLOAT,
    SalarioMin FLOAT,
    CONSTRAINT Solicitudes_Empleo__IDX PRIMARY KEY CLUSTERED (ID_Solicitud)
);
GO

CREATE TABLE Solicitudes_Tipos (
    ID_Solicitud INTEGER NOT NULL,
    ID_Solicitante INTEGER,
    ID_Puesto INTEGER,
    Tipo_Empleo VARCHAR (100) NOT NULL,
    CONSTRAINT Solicitudes_Tipos_PK PRIMARY KEY CLUSTERED (ID_Solicitud, Tipo_Empleo),
    CONSTRAINT Facturas_FK0v10 FOREIGN KEY (ID_Solicitud)
        REFERENCES Solicitudes_Empleo (ID_Solicitud)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Solicitudes_Tipos_Personas_FK FOREIGN KEY (ID_Solicitante)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
    CONSTRAINT Solicitudes_Tipos_Puestos_Trabajo_FK FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

CREATE TABLE Requisitos_Empleo (
    ID_Requisito INTEGER NOT NULL IDENTITY,
    ID_Solicitante INTEGER NOT NULL,
    Tipo_Puesto VARCHAR (100),
    Condiciones VARCHAR (200),
    Salario DECIMAL (10,2),
    Solicitantes_ID_Persona INTEGER NOT NULL,
    CONSTRAINT Requisitos_Empleo__IDX PRIMARY KEY CLUSTERED (ID_Requisito),
    CONSTRAINT Facturas_FK0v5 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO

ALTER TABLE Familiares
    ADD CONSTRAINT Facturas_FK0 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Datos_Sanitarios
    ADD CONSTRAINT Facturas_FK0v1 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Solicitudes_Tipos
    ADD CONSTRAINT Facturas_FK0v10 FOREIGN KEY (ID_Solicitud)
        REFERENCES Solicitudes_Empleo (ID_Solicitud)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Pagos_Solicitantes
    ADD CONSTRAINT Facturas_FK0v11 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Pagos_Empresas
    ADD CONSTRAINT Facturas_FK0v12 FOREIGN KEY (ID_Empresa)
        REFERENCES Empresas (ID_Empresa)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Tipos_Factura
    ADD CONSTRAINT Facturas_FK0v13 FOREIGN KEY (ID_Pago_Solicitante)
        REFERENCES Pagos_Solicitantes (ID_Pago)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Tipos_Factura
    ADD CONSTRAINT Facturas_FK0v14 FOREIGN KEY (ID_Pago_Empresa)
        REFERENCES Pagos_Empresas (ID_Pago)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Facturas
    ADD CONSTRAINT Facturas_FK0v15 FOREIGN KEY (ID_Tipo_Factura)
        REFERENCES Tipos_Factura (ID_Tipo_Factura)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Datos_Legales
    ADD CONSTRAINT Facturas_FK0v2 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Estudios
    ADD CONSTRAINT Facturas_FK0v3 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Experiencia_Laboral
    ADD CONSTRAINT Facturas_FK0v4 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Requisitos_Empleo
    ADD CONSTRAINT Facturas_FK0v5 FOREIGN KEY (Solicitantes_ID_Persona)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Puestos_Trabajo
    ADD CONSTRAINT Facturas_FK0v7 FOREIGN KEY (ID_Empresa)
        REFERENCES Empresas (ID_Empresa)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Puestos_Personas
    ADD CONSTRAINT Facturas_FK0v8 FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Puestos_Personas
    ADD CONSTRAINT Facturas_FK0v9 FOREIGN KEY (ID_Solicitante)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Familiares
    ADD CONSTRAINT Familiares_Personas_FK FOREIGN KEY (ID_Persona_Familiar)
        REFERENCES Personas (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Familiares
    ADD CONSTRAINT Familiares_TipoRelacion_FK FOREIGN KEY (IDRelacion)
        REFERENCES TipoRelacion (IDRelacion)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Solicitantes
    ADD CONSTRAINT Solicitantes_Personas_FK FOREIGN KEY (ID_Persona)
        REFERENCES Personas (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Solicitudes_Tipos
    ADD CONSTRAINT Solicitudes_Tipos_Personas_FK FOREIGN KEY (ID_Solicitante)
        REFERENCES Solicitantes (ID_Persona)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO

ALTER TABLE Solicitudes_Tipos
    ADD CONSTRAINT Solicitudes_Tipos_Puestos_Trabajo_FK FOREIGN KEY (ID_Puesto)
        REFERENCES Puestos_Trabajo (ID_Puesto)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;
GO
