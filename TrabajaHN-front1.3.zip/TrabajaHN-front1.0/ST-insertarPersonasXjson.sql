USE Agencia_Empleo
GO

--########################SECUENCIAS PARA LOS IDS#########################
CREATE SEQUENCE seq_persona_id
START WITH 1
INCREMENT BY 1;



--####################ST PARA INSERTAR SOLICITANTES#################
CREATE PROCEDURE insertar_solicitante
    @json NVARCHAR(MAX)
AS
BEGIN
    DECLARE @v_persona_id INT;

    -- Generar ID para la tabla Personas y usarlo para todas las tablas relacionadas
    SELECT @v_persona_id = NEXT VALUE FOR seq_persona_id;

    -- Insertar datos personales en la tabla Personas
    INSERT INTO Personas (ID_Persona, Nombre, Apellido, Fecha_Nacimiento, Direccion, Telefono, Email)
    SELECT @v_persona_id, 
           JSON_VALUE(@json, '$.Nombre'), 
           JSON_VALUE(@json, '$.Apellido'), 
           JSON_VALUE(@json, '$.Fecha_Nacimiento'), 
           JSON_VALUE(@json, '$.Direccion'), 
           JSON_VALUE(@json, '$.Telefono'), 
           JSON_VALUE(@json, '$.Email');

    -- Insertar datos de experiencia laboral si existen
    IF JSON_VALUE(@json, '$.Empresa') IS NOT NULL
    BEGIN
        INSERT INTO Experiencia_Laboral (ID_Solicitante, Empresa, Puesto, Anios_Experiencia)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.Empresa'), 
               JSON_VALUE(@json, '$.Puesto'), 
               JSON_VALUE(@json, '$.Anos_Experiencia');
    END

    -- Insertar datos de requisitos de empleo si existen
    IF JSON_VALUE(@json, '$.Tipo_Puesto') IS NOT NULL
    BEGIN
        INSERT INTO Requisitos_Empleo (ID_Solicitante, Tipo_Puesto, Condiciones, Salario)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.Tipo_Puesto'), 
               JSON_VALUE(@json, '$.Condiciones'), 
               JSON_VALUE(@json, '$.Salario');
    END

    -- Insertar datos de estudios si existen
    IF JSON_VALUE(@json, '$.Tipo_Estudio') IS NOT NULL
    BEGIN
        INSERT INTO Estudios (ID_Solicitante, Tipo_Estudio, Especialidad, Calificacion_Media)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.Tipo_Estudio'), 
               JSON_VALUE(@json, '$.Especialidad'), 
               JSON_VALUE(@json, '$.Calificacion_Media');
    END

    -- Insertar datos legales si existen
    IF JSON_VALUE(@json, '$.Servicio_Militar') IS NOT NULL
    BEGIN
        INSERT INTO Datos_Legales (ID_Solicitante, Servicio_Militar, Relacion_Justicia)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.Servicio_Militar'), 
               JSON_VALUE(@json, '$.Relacion_Justicia');
    END

    -- Insertar datos sanitarios si existen
    IF JSON_VALUE(@json, '$.Informacion_Sanitaria') IS NOT NULL
    BEGIN
        INSERT INTO Datos_Sanitarios (ID_Persona, Informacion_Sanitaria)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.Informacion_Sanitaria');
    END

    -- Insertar datos de familiares si existen
    IF JSON_VALUE(@json, '$.Nombre_Familiar') IS NOT NULL
    BEGIN
        INSERT INTO Familiares (Solicitantes_ID_Persona, ID_Persona_Familiar, IDRelacion, Nombre, Telefono)
        SELECT @v_persona_id, 
               JSON_VALUE(@json, '$.ID_Persona_Familiar'), 
               JSON_VALUE(@json, '$.ID_Relacion'), 
               JSON_VALUE(@json, '$.Nombre_Familiar'), 
               JSON_VALUE(@json, '$.Telefono_Familiar');
    END
END;

go


--################EJEMPLO DE INSERCCION#####################

